                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1333056
Customisable Module Socket for ESP8266 HC-05 etc by WDWHITE is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I've tried to make a customizable socket to fit any module you are trying to Program such as the ESP8266 wifi module or a HC-05 bluetooth module. Prity much any module that is based on being a board to be surface mounted.

The open SCAD file assumes that the left and right sides are mirrored and that if there are pins along the top then they are mirrored to the bottom.

The pins were sourced from a bag of different IC sockets. I broke apart the socket to recover the pins, then Straightened the legs of the pins. I found that sockets designed as through hole worked better for these sockets even if I intended the socket to be surface mounted.

In the end I used pins from a 84 pin PLCC socket search for "PLCC IC Socket" I chose a socket with through hole pins and a pin spacing of 2.54mm / 0.1 inch

The Open SCAD file can generate SVG files with the outline of the socket any holes needed and the placement of any copper pads. With that you will be able to then generate your own custom parts for your favorate PCB design software. Customizer can not work with generating SVG files so you would need to use open SCAD instead.

Also the Open Scad file can generate abase board to cover any off set pins.

Both these functions are experimental so don't rely on the default settings in the file.
I think for some pins the socket might need to be built in 3 parts

let me know what you think.

# Print Settings

Printer: CTC creator
Rafts: No
Supports: No
Resolution: 0.1
Infill: 100%

Notes: 
I've printed these in both PLA and ABS. The socket came out better in ABS however the text was more readable in PLA. there's not a massive differance in either.

I guess I would stick with the ABS as it is used more in industry.

# Custom Section

## Instructions

First source the pins you intend to use, as you will need to measure them for the customiser.
I found a PLCC socket, for square IC's with through hole pins, worked best as they have longer legs. 

Once you have your pins straighten the legs measure and put to one side. see pics
I used information from the PLCC socket's data sheet along with any physical measurments to get the information I needed to put in to the customizer.

From the data sheet for your module; add the width and height of the board I found a margin of 0.2mm worked fine otherwise the board is too tight in the socket. 

PAD_WIDTH  On the module when the pads meet the edge of the board no matter if it is on the horizontal or verticle edge that is the  PAD_WIDTH.  see pictures.

Pin settings.
see picture above as to which dimentions are which on the pins.

Text is any short lable you wish to print in to the socket leave as blank if you dont want any thing. I found this worked better when i printed in PLA than when I printed in ABS

Stud_Depth 

If creating a SMD version by bending the legs out to the side of the socket, then you might want some small studs to help place the socket whilst soldering. Also by creating longer studs I figure they could be passed through the PCB and the ends melted to stop the socket pulling away from the pcb inorder to help anchor the body of the socket.

Set to 0 if you don't want studs on the socket


Once you've printed the body of the socket. 

I drilled the holes for the pins as they were too fine for my machine.

Inorder to insert the pins I poked the leg of the pin through the hole first.

Then I applyed a little heat from a soldering iron, to help push the pin in to place also I applyed a little pressure to push the pin towards the back of it's recess. this melts then seals the hole for the leg as well just starting to melt the pin in to the back of the recess so that it grips the pin better.

So after printing I didn't end up using the base, I used a bit of epoxy to secure the socket on to the pcb then soldered the pins to the board.